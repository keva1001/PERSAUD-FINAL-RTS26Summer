





## Keva Persaud
Application 4 – Synchronization Quest (Part B)

Wokwi Link: https://wokwi.com/projects/470004634932556801

## Synchronization Primitives Used:
## Primitive  Implementation
Binary Semaphore  call_sem
ISR → nurse_ack_task
- This helps to signal a bedside nurse-
call event.
## -
Counting Semaphore  monitor_pool
- 3 monitor bays are available
- 4 tasks are contended for access
Mutex alarm_log _mux
- Helps to protect total _ alarms_ logged
are used by two concurrent writer
tasks

## Theme Integration:
- ISR Button -> the patient bedside call button
- Responder Task -> the nurse acknowledgment system
- Counting pool -> the available monitor bays
- Shared counter -> total alarms logged
- Writer tasks -> Station’s A and B alarm logging

## USE_PI_MUTEX 1:
Lock mode: MUTEX (priority inheritance ON) (USE_PI_MUTEX=1)
[PI] inversion demo lock = MUTEX (priority inheritance ON)
[PI][L] took lock @ 94577 us — entering CPU-bound section
[PI][H] wants lock @ 146761 us — blocking
[PI][H] ACQUIRED @ 12365290 us — waited 12218529 us (~12218 ms)  [lock=MUTEX
(priority inheritance ON)]





[PI][M] ready @ 12372049 us — burning CPU (takes no lock)


## USE_PI_MUTEX 0:
Lock mode: BINARY SEM (no inheritance) (USE_PI_MUTEX=0)
[PI] inversion demo lock = BINARY SEM (no inheritance)
[PI][L] took lock @ 93835 us — entering CPU-bound section
[PI][H] wants lock @ 146761 us — blocking
[PI][M] ready @ 196761 us — burning CPU (takes no lock)
[PI][M] done  @ 24775831 us (ran 24579070 us wall-clock)
[PI][L] released lock @ 37320559 us (held 37226724 us wall-clock)
[PI][H] ACQUIRED @ 37320600 us — waited 37173839 us (~37173 ms)  [lock=BINARY
SEM (no inheritance)]







Defense of choices:
1) Why binary sem for the signal path? What would break if you used counting?
A binary semaphore is used since the nurse's acknowledgment task only requires you to know
that a patient call button was pressed and now how many times it was pressed before getting a
response. The semaphore helps to signal that an event has happened in order to wake up the
waiting task. If we used a counting semaphore instead then multiple button presses would
register as separate counts before any of the nurse's acknowledgment tasks have a chance to run.
The tasks then have to process several queued events even though one acknowledgment for the
event should be enough.
2) Why counting semaphore for the pool, and what if you used N binary?
A counting semaphore is used for the monitor pool since it represents a pool of three identical
monitor bays which any task can use. With each successful take operation, it reserves one
monitor bay that's available, and then each give operation will return it to the pool. This lets any
of the four monitoring tasks to get whichever monitor first becomes available without needing to
know which one specific bay it is using. If we used N binary, it would require each task to search
for an available monitor bay or potentially permanently assign a specific bay which makes
implementation less flexible, which is bad since they are supposed to be interchangeable.

3) Why mutex for the writers? What if you used a binary sem as a lock?

Mutex is used for writers since both writer tasks will modify the total alarms logged
variable. It also helps to ensure that only one task is updating the counter at a time to
provide priority inheritance and prevent priority inversion. If we use a binary semaphore
as a lock, it can provide mutual exclusion; however, it doesn't provide ownership or





priority inheritance. Without ownership or priority inheritance, it can cause a high-
priority task to have a much longer than needed wait.

## Engineering Analysis:
- **Mutex vs binary semaphore as lock** — why use the mutex? Tie this to your two
measured H-wait numbers.

A mutex is used since it gives ownership semantics and priority inheritance. The high-
priority task (H) blocks a mutex that is held by a low-priority task (L) and then FreeRTOS is
temporarily raising L's priority, so the critical section can finish and then release the lock.
Whereas a Binary semaphore when used as a lock won't provide ownership or priority
inheritance and this can cause medium-priority task M to preempt L while L is still holding the
lock and thus causing H to wait a lot longer. In the two screenshots shown above, we see that H
waited 12, 218, 529 μs with the mutex vs. 37, 173, 839 μs with the binary semaphore. This is
roughly three times longer, and the entire difference is accounted for by almost exactly M's own
runtime during the binary-sem run.

- **Counting semaphore size** — why 3 (or whatever you picked)? What if 2? 4?

There are exactly 3 because the simulated ICU has three monitor bays which allow three
monitoring tasks to operate correctly and concurrently. If we had two then only two out of four
of the bays could be monitored at once even if a third is sitting idle. If its set to four then the
semaphore may let a fourth bay look for a monitor that doesn't physically exist and the software
wouldn't align with the hardware. Ultimately, the count has to equal the real resource inventory
perfectly.

- **Inversion timeline** — walk through H/M/L step-by-step. Quote your serial log from both
modes.

Mutex (PIP ON):
1)  L takes the mutex at t= 94,577 μs then enters a CPU-bound critical section.
2) H is ready and then blocks the mutex at t= 146, 761 μs.
3) Since its a mutex, FreeRTOS raises L's priority level from 5 to match H’s priority of 15
for as long as L holds the lock.





4) M is now ready, but at a priority of 10 it can't preempt L. So, it is then boosted to 15.
(M’s own line doesn’t show till t= 12,372, 049 μs which was after the handoff already
occurred!)
5) L is now finished and releases the mutex back to its original priority of 5.
6) H acquires the mutex at t= 12, 365, 290 μs with a measured wait of 12,218,529 μs.
7) The wait is L’s remaining critical section time; M never gets a chance to interfere.

Binary Semaphore as Lock (PIP OFF):
1) L takes the binary semaphore at t = 93,835 μs and starts its CPU section.
2) H is ready and then blocks at t= 146, 761 μs, same time as the mutex run, waiting for the
lock.
3) M is now ready at t= 196, 761 μs. Since the binary semaphore has no ownership and
inheritance, L is the only priority currently (priority 5) and M with a priority level of 10
will immediately preempt it.
4) M will run uninterrupted until t= 24, 775, 831 μs, during which L is making zero
progress.
5) L resumes and then releases the lock at t= 32,320, 559 μs and then H gets the lock.
6) H will now have a measured wait of 37,173, 839 μs. H will wait for L’s remaining work
plus M’s execution time to produce a much larger delay.

- **Induced failure** — predicted vs observed symptoms. Deterministic or only sometimes?

I chose to remove the mutex from the two writer tasks that were guarded by the
INDUCE_FAILURE compile switch around the total alarms logged. My prediction was that
without mutual exclusion, then both our stations would read the same value before either task has
a chance to write the updated value. This would then cause the lost update race condition since
one increment would potentially overwrite the other before our counter is deemed incorrect.
When I induced fail, both the alarm logging tasks were sometimes both accessing the shared
counter at the same time. This caused the serial monitor to show both tasks as reading the same
old value and then writing it back as the same incremented value. For example, both station A
and B log "10->11," which means instead of the counter going from 10-12, both tasks write 11
which causes one alarm count to become lost. This failure is not deterministic since it only
happens when the scheduler switches between the two tasks at particular points between reading
and writing the shared variable. Most of the time it executes correctly, however, when both tasks
intertwine at the wrong time it causes the race condition to occur.






## Concurrency Diagrams:
-SEE THE PDF TITLED "README_APP_4" FOR THE DIAGRAM PICTURES!!!

Binary Semaphore pair:
- The tasks blocked on xSemaphoreTake until the buton ISR fires then the green arrow
shows the unblock.
Counting sempahore for the pool:
- Shows the four bay tasks that are contending for the three slots and the fourth is forced to
block till one is released.






## Mutex Protecting "total _alarms _logged":
- When station A is holding it while station B is blocked.

AI Disclosure:
- For this application, I used AI to double check that I got all the parts required in the
rubric correctly completed, as well as to help me create my concurrency diagrams.
o Link: https://claude.ai/share/af473949-7873-4a08-b0f7-d4b82b886f86