Keva Persaud 

Application 5- Dual-Core IPC Pipeline Architecture 

# **Theme: ICU Bedside ECG Telemetry & Nurse Call System** 

In this application, it's supposed to be a dual-core FreeRTOS pipeline on the ESP32. The system is to simulate an ICU bedside monitoring device which should continuously acquire patient 

telemetry and then analyze that data for any abnormal vital signs and then coordinates processing using IPC primitives and then dispatches an alert automatically or to a nurse-call interrupt. 

# **System Architecture:** 

This real-time task consists of four tasks: 

_1._ Task A -> Telemetry Sampler (P8, C1): This task is to sample ECG, heart rate, and 

   - O2 every 50ms and then send one medical _ telemetry _ t packet to the queue. T 

2. Task B -> Arrhythmia Processor (P8, C1): Waits for the queued telemetry and then analyzes the sample for any abnormal heart rhythms and then stores the latest diagnosis. 

3. Task C -> Pipeline Coordinator (P9, C1): Waits for both the producer and consumer’s works to be completed and then use their work in an event group rendezvous before 

triggering the next pipeline stage. 

4. Task D-> Alarm Dispatch Actuator (P12, C1): Waits for a direct task notification and 

   - then immediately dispatches an automatic alarm or responds to a manual nurse- call 

interrupt. 

The Http monitor server executes independently on Core 0 so that network traffic and web page generation can't interfere with deterministic scheduling on the real-time processing core. 

# **Engineering Analysis Prompts:** 

# **1. Why pin the web server to Core 0? What goes wrong if it's on Core 1?** 

We pin the web server to core 0 since it preforms non-real-time operations like Wi-fi 

communication, handling HTTP requests, refreshing the dashboard, or generating HTML pages. Since these operations are unpredictable and could block while waiting for any network activity, keeping the webserver on core 0 let's core 1 remain dedicated to all real-time telemetry pipeline (tasks A-D) which ensures deterministic scheduling and lower latency. If it's on core 1, then it would conflict and compete with the real-time tasks for CPU time. This could potentially 

increase scheduling delays and cause the producer or consumer to miss a deadline, or the queue occupancy may increase or overflow and we could potentially miss or delay critical alarm notifications which is detrimental to the patients. When we separate the webserver to core 0, it helps to improve system responsiveness and helps to maintain the predictable real-time performance. 

# **2. Queue depth — how sized? Compute the burst rate you protect against.** 

The queue depth was configured as 10 items. This is because the producer task normally 

generates one telemetry sample every 50ms/ 20 Hz and since each queue entry will store one 

telemetry packet the queue depth is 10 samples over the sampling period of 50ms/sample which when multiplied by one another is 500ms. Thus, the queue can buffer approximately 500ms of telemetry data before it is full, which means that it can handle half a second of temporary processing delays before a sample gets dropped. If the producer can't process the data within this time, then the producer increments the dropped_samples counter when the xQueueSend() fails. 

The queue transfers object of type medical telemetry__ t from Task A to Task B. The producer is task A (50ms periodic sampler), the consumer is task B (the block waiting for new telemetry), and the queue depth is 10 entries. The producer timeout is when the producer attempts to enqueue a short timeout and if the queue remains full then the new sample is dropped and the dropped sample counter gets incremented instead of re-writing older telemetry information as if should. The consumer timeout is when task B has to wait up to 100ms for a new telemetry reading before it times out. This contract ensures that telemetry is processed FIFO while preventing the producer from blocking long enough to miss the 50ms sampling deadline. 

# **3. Event group vs N semaphores — when is each better?** 

An event group is better when a task must wait for multiple events simultaneously. In this application, Task C has to wait for both Task A which places the telemetry in the queue and task B which is the consumer that has to finish processing that telemetry. This is a AND-wait synchronization pattern which is what event groups are made for. N semaphores are better when signaling individual events or controlling access to shared resources. For this application, the coordinator waits until both the producer and consumer have both completed by waiting for the produced and processed bits. 

# **4. Direct notification vs binary semaphore — measure both wakeup latencies.** 

The average latency of direct task notification based on one of the runs I did is about (30 + 30 + 32 + 29 + 31 + 29 + 30 + 20) / 8 = 28.9 μs and the average latency of the binary semaphore is about (152 + 257 + 793 + 528 + 690 + 575 + 717 + 448)/8 = 520 μs. Therefore, the semaphore took about 18x longer (520/28.9) to wake than the direct notification. For this part, I measured the wakeup latency of both synchronization mechanisms via tweaking my existing code and testing in a new window in order to not disturb my current code. The direct task notification was consistently waking the waiting task in approximately 20-32 μs with an average calculated latency of 28.9 μs.  The binary semaphore required more time; it ranged from 152- 793 μs with an average latency of 520 μs. This means that the direct task notification was approximately 18 times faster than the binary semaphore in this benchmark. Direct task notification provides a lower latency since they signal a task directly without allocating or managing any separate kernel objects. However, a binary semaphore is implemented as a queue object which includes additional overhead during operations that involve give/take. For one-one task signaling, direct task notifications are preferred since binary semaphores are better when there are multiple tasks waiting on the same event or when a separate synchronization object is needed. 

<u>FROM TERMINAL (adjusted my code on a separate workspace):</u> 

<u>(WOKWI LINK TO CODE THAT GOT ME THE NUMBERS BELOW:</u> 

<u>https://wokwi.com/projects/470917097285193729)</u> 

ESP—-ROM: €sp32s3-20210327 Build:Mar 27 2021 

rst:0xl (POWERON) ,boot:0x8 (SPI _ FAST FLASH BOOT) SPIWP:0Oxee 

mode:DIO, clock div:1 load: 0x3fce3808, len:0x370 load:0x403c97len: **0** x9000, load:0x403cc700, len:0x2364 entry Ox403c98ac 

—--— FreeRTOS Interrupt Latency Benchmark --—— Benchmark running on GPIO 18. Press the button to trigger ISR... [Notification] Wakeup Latency: 30 us [Semaphore ] Wakeup Latency: 152 us [Notification] Wakeup Latency: 30 us [Semaphore] Wakeup Latency: 257 us [Notification] Wakeup Latency: 32 us [Semaphore ] Wakeup Latency: 793 us [Notification] Wakeup Latency: 29 us [Semaphore] Wakeup Latency: 528 us [Notification] Wakeup Latency: 31 us [Semaphore ] Wakeup Latency: 690 us [Notification] Wakeup Latency: 29 us [Semaphore] Wakeup Latency: 575 us [Notification] Wakeup Latency: 30 us [Semaphore ] Wakeup Latency: 717 us [Notification] Wakeup Latency: 20 us [Semaphore] Wakeup Latency: 448 us | 



<!-- Start of picture text -->
Task A — producer<br>20 Hz telemetry sampling<br>Queue<br>depth 10, typed FIFO<br>Producer also sets<br>PRODUCED bit directly<br>Task B — consumer<br>arrhythmia threshold check<br>Event group<br>wait for both bits<br>Task C — coordinator Button ISR<br>rendezvous, clears bits nurse call, debounced<br>direct notify<br>direct notify<br>from ISR<br>Task D — responder<br>alert actuator, prio 12<br><!-- End of picture text -->

Core 1 Real-time IPC pipeline Task A — producer - 20 Hz: prio 8 Task B — consumer - prio; 8 Task C — coordinator - prio 9 Task D — responder - prio 12 Shared IPC: queue (depth 10), event group 



<!-- Start of picture text -->
read<br><!-- End of picture text -->

Core 0 Observability plane Serial monitor (1 Hz) or HTTP web server Reads queue depth, event bits, heartbeats 

direct notify - Task D Button ISR (GPIO 18) debounced, nurse call 



```
"  body { font-family: -apple-system, sans-serif; background: #FAFAF5; "
"         color: #1A1A1A; padding: 1.5rem; }"
"  h1 { color: #6B4F09; border-bottom: 3px solid #FFC904; "
"       display: inline-block; padding-bottom: 4px; }"
"  table { border-collapse: collapse; margin: 1rem 0; width: 100%%; max-
width: 800px; }"
"  th { background: #1A1A1A; color: #FFC904; padding: 8px 14px; "
"       text-align: left; font-size: 12px; text-transform: uppercase; }"
"  td { padding: 8px 14px; border-bottom: 1px solid #ddd; }"
```

```
"  td.num { font-variant-numeric: tabular-nums; font-weight: 700; color:
#6B4F09; }"
"  .card { background: white; padding: 15px; margin-bottom: 15px; border-
radius: 6px; "
"          box-shadow: 0 2px 5px rgba(0,0,0,0.08); max-width: 800px; }"
"  .alert { color: #e74c3c; font-weight: bold; }"
"  .normal { color: #2ecc71; font-weight: bold; }"
"</style></head>"
"<body>"
```

- <mark>`"<h1>ICU ECG Telemetry &mdash; Dual-Core IPC Pipeline</h1>"`</mark> 

```
"<div class=\"card\">"
"  <h3>Current Telemetry Payload (Bed %lu)</h3>"
"  <p>Status: <span class=\"%s\">%s</span></p>"
"  <p><b>Heart Rate:</b> %u BPM | <b>SpO2:</b> %u%% | <b>ECG Wave:</b> %d
mV</p>"
"  <p><b>IPC Queue Depth:</b> %u / %d | <b>Event Bits:</b> 0x%02X</p>"
"</div>"
"<table>"
```

- <mark>`"<thead><tr><th>Task</th><th>Role</th><th>Period / Trigger</th>" "<th>Priority</th><th>Heartbeats</th><th>WCET`</mark> 

- <mark>`(&micro;s)</th></tr></thead>" "<tbody>"`</mark> 

   - <mark>`"<tr><td>Task A &mdash; Telemetry Sampler</td><td>Producer</td>" "<td>50 ms</td><td>8</td>"`</mark> 

   - <mark>`"<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"`</mark> 

   - <mark>`"<tr><td>Task B &mdash; Arrhythmia Process</td><td>Consumer</td>" "<td>Queue Event</td><td>8</td>" "<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"`</mark> 

   - <mark>`"<tr><td>Task C &mdash; Pipeline Coordinator</td><td>Rendezvous</td>" "<td>Event Group</td><td>9</td>" "<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"`</mark> 

```
"<tr><td>Task D &mdash; Alarm Dispatcher</td><td>Actuator</td>"
"<td>Notification</td><td>12</td>"
"<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
"</tbody></table>"
```

```
"<div class=\"card\">"
```

```
"  <p><b>Auto Arrhythmia Alerts:</b> %lu | <b>Manual Nurse Calls:</b> %lu
| <b>Dropped Samples:</b> %lu</p>"
"</div>"
```

```
"<p style=\"font-size: 0.85rem; color: #666;\">Auto-refreshing every 1 s
&mdash; heartbeats must grow monotonically.</p>"
"</body></html>",
```

```
(unsignedlong)last_sample.patient_id,
```

```
(last_verdict == RHYTHM_ARRHYTHMIA)?"alert":"normal",
```

```
(last_verdict == RHYTHM_ARRHYTHMIA)?"ARRHYTHMIA DETECTED":"RHYTHM
NORMAL",
        last_sample.heart_rate_bpm, last_sample.spo2_percent, last_sample.ecg_mv,
(unsigned)depth, QUEUE_DEPTH,(unsigned)bits,
```

```
(unsignedlong)hb_a,(unsignedlonglong)wcet_a_max_us,
```

```
(unsignedlong)hb_b,(unsignedlonglong)wcet_b_max_us,
```

```
(unsignedlong)hb_c,(unsignedlonglong)wcet_c_max_us,
```

```
(unsignedlong)hb_d,(unsignedlonglong)wcet_d_max_us,
```

```
(unsignedlong)arrhythmia_alerts,(unsignedlong)manual_nurse_calls,
(unsignedlong)dropped_samples);
```

```
    httpd_resp_set_type(req,"text/html");
    httpd_resp_send(req, buf, n);
return ESP_OK;
}
```

```
static httpd_handle_t start_webserver(void)
{
```

```
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port   = HTTP_PORT;
    cfg.core_id       =0;
    cfg.task_priority =5;
    cfg.stack_size    =8192;
    httpd_handle_t s   = NULL;
if(httpd_start(&s,&cfg)== ESP_OK){
```

```
={.uri="/",.method=HTTP_GET,
```

```
.handler=handle_root,.user_ctx=NULL };
```

```
        httpd_register_uri_handler(s,&root);
        ESP_LOGI(TAG,"[WEBMON] HTTP server started on port %d", HTTP_PORT);
}
return s;
}
staticvoid wifi_event_handler(void*arg, esp_event_base_t base,
```

```
int32_t id,void*data)
```

```
{
```

```
if(base == WIFI_EVENT && id == WIFI_EVENT_STA_START)
esp_wifi_connect();
elseif(base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED)
esp_wifi_connect();
```

```
elseif(base == IP_EVENT   && id == IP_EVENT_STA_GOT_IP){
```

```
*e =(ip_event_got_ip_t *)data;
```

```
        ESP_LOGI(TAG,"[WEBMON] IP Address assigned: " IPSTR, IP2STR(&e-
>ip_info.ip));
```

```
();
```

```
}
}
```

```
staticvoid wifi_init_sta(void)
{
```

```
    ESP_ERROR_CHECK(nvs_flash_init());
```

```
    ESP_ERROR_CHECK(esp_netif_init());
```

```
    ESP_ERROR_CHECK(esp_event_loop_create_default());
```

```
    esp_netif_create_default_wifi_sta();
```

```
    wifi_init_config_t init = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init));
```

```
    esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
wifi_event_handler, NULL);
```

```
    esp_event_handler_register(IP_EVENT,   IP_EVENT_STA_GOT_IP,
wifi_event_handler, NULL);
```

```
    wifi_config_t cfg ={.sta ={.ssid = WIFI_SSID,.password = WIFI_PASS,
.threshold.authmode = WIFI_AUTH_OPEN }};
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA,&cfg));
    ESP_ERROR_CHECK(esp_wifi_start());
}
```

```
staticvoid webmonitor_task(void*arg)
{
    wifi_init_sta();
for(;;){
        vTaskDelay(pdMS_TO_TICKS(1000));
}
}
#else/* USE_WEBSERVER == 0 */
```

```
/* ============================================================
```

```
 *  TERMINAL MONITOR (Core 0) [USE_WEBSERVER = 0]
```

```
 * ============================================================ */
```

```
staticvoid task_monitor(void*arg)
```

```
{
```

```
    TickType_t last = xTaskGetTickCount();
```

```
const TickType_t period = pdMS_TO_TICKS(1000);
```

```
for(;;){
```

```
=
        UBaseType_t depth  uxQueueMessagesWaiting(data_q);
```

```
=
        EventBits_t bits   xEventGroupGetBits(evt_group);
```

```
("\n=== ICU ECG Telemetry Monitor · Dual-Core IPC Pipeline ===\n");
("Telemetry: Status=%s | HR=%u BPM | SpO2=%u%% | ECG=%d mV\n",
```

```
(last_verdict == RHYTHM_ARRHYTHMIA)?"ARRHYTHMIA":"NORMAL",
```

```
               last_sample.heart_rate_bpm, last_sample.spo2_percent,
last_sample.ecg_mv);
```

```
("IPC State: Queue Depth=%u/%d | EventBits=0x%02X\n",
```

```
(unsigned)depth, QUEUE_DEPTH,(unsigned)bits);
```

```
("%-30s %-8s %-9s %-12s %-10s\n",
```

```
"Task","Period","Priority","Heartbeats","WCET(us)");
```

```
("%-30s %-8s %-9d %-12lu %-10llu\n",
```

```
"A: Telemetry Sampler (Prod)","50 ms",8,(unsignedlong)hb_a,
(unsignedlonglong)wcet_a_max_us);
```

```
("%-30s %-8s %-9d %-12lu %-10llu\n",
```

```
"B: Arrhythmia Process (Cons)","Queue",8,(unsignedlong)hb_b,
(unsignedlonglong)wcet_b_max_us);
```

```
("%-30s %-8s %-9d %-12lu %-10llu\n",
```

```
"C: Pipeline Coordinator","Rendezvous",9,(unsigned
long)hb_c,(unsignedlonglong)wcet_c_max_us);
```

```
("%-30s %-8s %-9d %-12lu %-10llu\n",
```

```
"D: Alarm Dispatch Actuator","Notif",12,(unsignedlong)hb_d,
(unsignedlonglong)wcet_d_max_us);
```

```
("Stats: Auto Alerts=%lu | Nurse Calls=%lu | Drops=%lu\n",
```

```
(unsignedlong)arrhythmia_alerts,(unsigned
```

```
long)manual_nurse_calls,(unsignedlong)dropped_samples);
```

```
        vTaskDelayUntil(&last, period);
```

```
}
```

```
}
#endif/* USE_WEBSERVER */
```

**What I copied from APP 3:** 

```
staticvolatileint64_t last_edge_us =0;
staticvoid IRAM_ATTR button_isr(void*arg)
{
```

```
int64_t now = esp_timer_get_time();
```

```
if(now - last_edge_us <200000)return;/* 200 ms software debounce */
    last_edge_us = now;
```

```
    manual_nurse_calls++;
```

```
if(responder_handle != NULL){
        BaseType_t woken = pdFALSE;
```

```
        vTaskNotifyGiveFromISR(responder_handle,&woken);
        portYIELD_FROM_ISR(woken);
```

```
}
}
```

```
/* 4. Hardware Trigger ISR (Nurse Call Button) */
```

```
=
    gpio_config_t cfg {
```

```
.pin_bit_mask =1ULL<< BUTTON_GPIO,
.mode         = GPIO_MODE_INPUT,
.pull_up_en   = GPIO_PULLUP_ENABLE,
```

```
.intr_type    = GPIO_INTR_NEGEDGE,
```

```
};
    gpio_config(&cfg);
    gpio_install_isr_service(0);
    gpio_isr_handler_add(BUTTON_GPIO, button_isr, NULL);
```

```
staticvoid responder_task(void*arg)
{
```

```
for(;;){
uint32_t n = ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
if(n ==0)continue;
```

```
=
uint64_t t_start  esp_timer_get_time();
```

```
if(last_verdict == RHYTHM_ARRHYTHMIA){
            ESP_LOGW(TAG,"[ACTUATOR] CRITICAL VITAL ALARM! Bed: %lu | HR: %u BPM
| SpO2: %u%% | Triggers: %lu",
```

```
(unsignedlong)last_sample.patient_id,
```

```
                     last_sample.heart_rate_bpm,
```

```
                     last_sample.spo2_percent,
```

```
(unsignedlong)n);
```

```
}else{
            ESP_LOGI(TAG,"[ACTUATOR] Routine cycle check normal. Bed: %lu |
HR: %u BPM | SpO2: %u%%",
```

```
(unsignedlong)last_sample.patient_id,
```

```
                     last_sample.heart_rate_bpm,
```

```
                     last_sample.spo2_percent);
```

```
}
```

```
++;
```

```
        MEASURE_WCET(t_start, wcet_d_max_us);
}
}
```

```
/* Utility macro for WCET measurement */
```

```
#define MEASURE_WCET(start_time, max_var)do{                            \
uint64_t elapsed = esp_timer_get_time()- start_time;                 \
if(elapsed > max_var){ max_var = elapsed;}                         \
}while(0)
```

# **AI Disclosure:** 

- I used AI to help me build my concurrency diagrams as well as to ensure that I correctly 

meet all parts of the rubric to ensure that I gain maximum points. 

- LINK: https://claude.ai/share/f894576d-e2f5-4796-92c5-66ab4d012b8b 

