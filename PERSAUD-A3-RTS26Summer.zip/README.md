Application 3 – ISR + Bottom – Half Pattern README Theme: Medical – ICU Patient-Call Monitor 

#1 System Overview: 

**Load 0:** 

**==> picture [305 x 614] intentionally omitted <==**

**----- Start of picture text -----**<br>
SSS ——2————— 535858585855 ss» x SSSR<br>Simulation Description<br>Oo a ou © 00:38.884 (100%<br>Ee = = WOKWI<br>i == = age<br>ae a =e<br>4 WAVESCOPE<br>@ BIN GPIO 18 / IN |<br>HM GPIO 19 / OUT |<br>**----- End of picture text -----**<br>


**Load 1:** 

**==> picture [74 x 8] intentionally omitted <==**

**----- Start of picture text -----**<br>
Simulation Description<br>**----- End of picture text -----**<br>


**==> picture [340 x 282] intentionally omitted <==**

**----- Start of picture text -----**<br>
bckt race: 0x4037811A: 0x3FC93E80_0x40377181:0x3FC93FA0_ 0x4200971D: 0x3FCA1A30_0x4037A625:<br>4 WAVESCOPE<br>@ BIN GPIO 18 / IN |<br>@ GPIO 19 / OUT |<br>**----- End of picture text -----**<br>


## **#Engineering Analysis:** 

1) **What's in your ISR? What's NOT?**** List every line. Defend each (or remove it). 

## **What is in my ISR:** 

`static void IRAM_ATTR button_isr(void *arg)` 

`{` 

`int64_t now = esp_timer_get_time();` 

`/* Debounce: drop edges within DEBOUNCE_US of last accepted one. */` 

`if (now - last_edge_us < DEBOUNCE_US) return;` 

`last_edge_us = now;` 

`/* 1. Toggle the scope output HIGH so the logic analyzer can see ISR entry. */ gpio_set_level(ISR_PULSE_GPIO, 1);` 

```
    isr_entry_time_us = now;
    presses_observed++;
```

```
    BaseType_t higher_woken = pdFALSE;
```

```
/* 2. Signal via binary semaphore.
     *    Multiple presses while taken can be LOST — binary sem has no count. */
    xSemaphoreGiveFromISR(btn_sem,&higher_woken);
```

```
/* 3. Signal via direct task notification.
     *    Faster than the semaphore on most ports; one-to-one. */
    vTaskNotifyGiveFromISR(task_notif_handle,&higher_woken);
```

```
/* 4. Toggle scope output LOW — ISR is about to return. */
    gpio_set_level(ISR_PULSE_GPIO,0);
```

```
/* 5. Request a context switch on ISR exit if a higher-priority task is
ready. */
    portYIELD_FROM_ISR(higher_woken);
}
```

## **Why it’s there:** 

- Line 1: int64_t now = esp_timer_get_time(): This is in my ISR because it reads the current time in ms and then uses the timestamp to interrupt and preform software debounce. 

- Lines 2-5: if (now - last_edge_us < DEBOUNCE_US) return; 

last_edge_us = now; 

The purpose of these lines is to implement the software debounce and to ignore button presses that occur too soon after the previously accepted button press. These lines help to prevent one physical press from generating multiple interrupts due to the switch to bounce. 

- Line 6: int64_t now = esp_timer_get_time(): The purpose of this linie is to raise GPIO19 -> HIGH and it also marks the beginning of ISR execution. It essentially allows the logic analyzer to measure the ISR response time. 

- Lines 7-8: isr_entry_time_us = now; 

presses_observed++; 

The purpose of these two lines is to save the ISR entry timestamp so that the bottom-half tasks are able to compute latency. These lines also count the number of accepted button presses. 

- Line 9: BaseType_t higher_woken = pdFALSE: The purpose of this line was to track whether or not each ISR API wakes up a higher-priority task. It's required by FreeRTOS ISR functions. 

- Lines 10-13: xSemaphoreGiveFromISR(btn_sem, &higher_woken): These lines help to give the binary semaphore from the ISR then it wakes the semaphore bottom-half task and then it demonstrates ISR-to-task communication using a binary semaphore. 

- Lines 14-17: vTaskNotifyGiveFromISR(task_notif_handle, &higher_woken): This line's purpose is to send a direct task nofication in the bottom-half task. 

- Line 18: gpio_set_level(ISR_PULSE_GPIO, 0): Lowers GPIO19 and marks the end of the ISR execution. 

- Line 22: portYIELD_FROM_ISR(higher_woken): This final line requests an immediate context switch if a higher-priority take is ready. If we didn’t include this line, then the ISR would return and the task wouldn’t be executed until the next scheduler tick, which would lead to an increased latency. 

## **What’s NOT inside the ISR:** 

Not inside the ISR includes any blocking functions like we learned about in Homework 5.  There also aren’t any dynamic memory allocation functions such as malloc() and free, as well as delays, long loops, mutex operations, and heavy computations. These operations are avoided since ISR should be short/completed as quickly as possible. Logging and other blocking operations such as the ones I listed above increase interrupt latency, or they aren’t safe to call from and ISR since they would potentially block or rely on kernels that aren’t available in the interrupt context. 

- 2) **Binary semaphore vs direct task notification**** — quote your measured latency numbers. Which is faster? Why? 

## **WITH_LOAD = 0:** 

Notification-> max = 30 µs 

Semaphore -> max = 5828 µs 

**WITH_LOAD = 1;** Notification -> max = 2515 µs Semaphore -> max = 6809 µs 

-Based of the measurements I got, the direct task notification was faster overall. This is because, under idle conditions the notification task had a maximum latency of only 30 µs while the semaphore task reached 5828 µs. When the system had a load of 1, the notification path did increase however, compared to the semaphore task it was still less than it (2515 µs < 6809 µs). Thus, showing that the notification mechanism is faster since the direct task notifications are built directly into each tasks task control block and when the ISR 

calls ”vTaskNotifyGiveFromISR(),” FreeRTOS can only update the field in the waiting task and then make it as ready to run. A binary semaphore is implemented in an internal queue. When you call xSemaphoreGiveFromISR() it needs FreeRTOS in order to manipulate the queued object before waking the waiting task and introducing the additional overhead. Direct task notifications normally provide a lower latency and less overhead than binary semaphores when they communicate from the ISR -> a single task. 

- 3) **Latency under load**** — quote idle (`WITH_LOAD 0`) vs loaded (`WITH_LOAD 1`) numbers. By what factor does latency increase? Use the priority geometry above (Task A at 15 outranks in your bottom half at 12) to explain _*which*_ load task is responsible for the worst-case increase, and why B/C/D are not. 

Increase Calculations: 

- 2515 / 30 = 83.8 = ~84x slower (NOTIFICATION) 

- 6809/ 5828 = ~1.17x slower (SEMAPHORE) 

   - The largest increase in the maximum latency was the direct task notification, which is about 84x higher under load of 1, and the binary semaphore of about 1.17x higher under a load of 1. The largest increase is caused by Task A since it runs at priority 15. The bottom-half tasks run at priority 12 so whenever Task A is executing it can suspend the bottom-half tasks to delay their execution after the ISR is complete. The other background tasks (Task B-D) have priorities 10, 8, and 6 correlating respectively. Since all these priorities rank lower than the bottom half task’s priority of 12, they aren’t able to preempt the bottom-half once we can run. Thats why they aren’t responsible for the worst-case latency increase, only Task A has a higher priority than the bottom half- talk 

and can therefore delay the ISR’s deferred processing and thus produce the observed worst-case latency. 

- 4) **Induced failure**** — name the rule you broke, the predicted symptom, the observed symptom, and how they match (or don't). 

   - **Prediction:** I decided to remove portYIELD_FROM_ISR() which's job is to “Request a context switch on ISR exit if a higher-priority task is ready.” By 

commenting out this line and breaking this rule, I predict that it will prevent the scheduler from properly immediately switching to the higher-priority bottom-half tasks after the ISR exits. We should still get the signal semaphore and task notifications; however, I think the bottom-half task won’t run till the next scheduler tick, and this can increase latency. 

- **Observed:** I observed that the application had continued to function and reported the semaphore and notifications as normal. However, both of their latencies increased since the bottom-half tasks don’t execute immediately after the ISR is completed. Once I added that line back in, the latency returned to its original values. 

## **Concurrency Diagrams:** 

**Latency Tables:** 

## **AI Disclosure:** 

- For this project I did use CLAUDE AI to ensure that I meet all the requirements of the rubric. I also used it to help me build my concurrency diagrams and latency tables. I also used the provided AI link to help me make my waveforms. 

- VCD viewer: file:///C:/Users/kevap/Downloads/wavescope%20(1).html 

- CLAUDE AI LINK: https://claude.ai/share/a40d62c5-1f8e-44d6-9895-107abe74c8d0 