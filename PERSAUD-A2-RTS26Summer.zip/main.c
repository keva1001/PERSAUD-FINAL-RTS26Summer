/*
 * Application 2 — Multi-task system with scheduling defense
 *
 * Scaffold level: ~70% complete.
 *
 * Scaffold Code - AI usage:
 *   Addition of the comment blocks for "real esp32 function" and the "compute standins"
 *   Logic to allow for switching between webserve mode and pure logging mode
 *   Commenting of code including human readable summaries
 *
 * What this scaffold gives you:
 *   - Architecture from App 1 (dual-core, HTTP server) reused.
 *   - Four FreeRTOS task skeletons, all pinned to Core 1, with priorities pre-assigned.
 *   - Per-task heartbeat counters wired into the web page.
 *   - A WCET measurement helper (MEASURE_WCET) you can wrap around any task body.
 *
 * What you do:
 *   1. Rename the task names and log strings for YOUR theme.        [DONE]
 *   2. Implement each task's body.                                  [DONE]
 *   3. Defend the priority assignment in your README.               [DONE]
 *   4. Measure WCET for each task with MEASURE_WCET. Report mean/max. [DONE]
 *   5. Demonstrate preemption: log a timestamp before/after, show in
 *      your README that a higher-priority task interrupts a lower one. [DONE]
 *
 * ============================================================
 *  OUTPUT MODE  (web monitor vs. terminal-only monitor)
 * ============================================================
 *
 *   USE_WEBSERVER = 1  -> Wi-Fi + HTTP server, auto-refreshing web page
 *   USE_WEBSERVER = 0  -> No Wi-Fi, no HTTP. Serial console monitor (default).
 *
 * ============================================================
 * Theme: Medical — ICU Cardiac Monitor
 *
 * Priority defense (Rate-Monotonic Scheduling):
 *   - SHORTER PERIOD = HIGHER PRIORITY  (RMS rule)
 *   - Deadline D = Period T  for all four independent periodic tasks
 *   - Liu-Layland bound: U_LL = n(2^(1/n) - 1) = 4(2^(1/4) - 1) ≈ 0.7568
 *
 * Task map:
 *   A (10 ms,  pri 15) — ECG sample + IIR filter      — highest rate, highest priority
 *   B (20 ms,  pri 10) — Arrhythmia detection (FIR)
 *   C (50 ms,  pri  5) — Alarm dispatch + CRC stamp
 *   D (100 ms, pri  2) — Audit log / pending-alarm sort — lowest rate, lowest priority
 * ============================================================
 */

#ifndef USE_WEBSERVER
#define USE_WEBSERVER 0
#endif

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_timer.h"

#if USE_WEBSERVER
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_http_server.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#endif

#define WIFI_SSID  "Wokwi-GUEST"
#define WIFI_PASS  ""

static const char *TAG = "ecg_monitor";

/* ---------- Per-task heartbeat counters ----------
 * Each task increments its counter at the end of every iteration.
 * Single 32-bit reads are atomic on Xtensa so no mutex needed here. */
static volatile uint32_t hb_a, hb_b, hb_c, hb_d;

/* ---------- WCET measurement helper ----------
 *
 * Usage:
 *   uint64_t wcet_a_max_us = 0;
 *   MEASURE_WCET(wcet_a_max_us, { <task body> });
 *
 * Records the maximum observed wall time across all invocations.
 * Place your ESP_LOGI tick line OUTSIDE this macro so logging latency
 * does not inflate the WCET measurement.
 */
#define MEASURE_WCET(_max_var, _body) do {                       \
    int64_t _t0 = esp_timer_get_time();                          \
    _body;                                                        \
    int64_t _dt = esp_timer_get_time() - _t0;                    \
    if ((uint64_t)_dt > (_max_var)) (_max_var) = (uint64_t)_dt;  \
} while (0)

/* Storage for WCET-max per task. Logged periodically inside Task D. */
static uint64_t wcet_a_max_us, wcet_b_max_us, wcet_c_max_us, wcet_d_max_us;

/* ---------- Shared data (producer → consumer between tasks) ----------
 * Reads/writes are sequenced by the FreeRTOS scheduler on Core 1.
 * No mutex needed for these single-word variables (yet — App 6 changes this). */
static volatile int32_t a_latest_sample = 0;   /* A → B */
static volatile bool    b_alarm_flag    = false; /* B → C */
static volatile uint32_t b_alarm_count  = 0;

/* --- Static buffers: initialized ONCE in app_main, NOT inside a task --- */

/* Task B — FIR filter input buffer and coefficients */
#define B_SAMP 128   /* must be a power of 2 for the bitmask index to work */
#define B_TAPS 16
static float b_buf[B_SAMP];
static float b_coef[B_TAPS];
static volatile float b_sink;   /* volatile — defeats dead-code elimination */

/* Task C — synthetic telemetry/alarm packet for CRC-32 stamp
 * 2048 bytes → ~23 ms measured. Tune C_LEN up/down to hit 1–5 ms target.
 * NOTE: at 2048 the measured WCET is ~23 ms which already exceeds the 50 ms
 * period headroom, so we keep it to demonstrate the workload and note the
 * utilization in the README. */
#define C_LEN 2048
static uint8_t c_pkt[C_LEN];
static volatile uint32_t c_sink;

/* Task D — insertion sort array
 * WATCHDOG FIX: original D_N=1500 produced ~3.7 s WCET on Wokwi, which
 * starved the IDLE1 task and triggered the FreeRTOS task watchdog.
 * Reduced to D_N=200 → WCET ≈ a few ms, well under the 100 ms period. */
#define D_N 200
static int d_arr[D_N];
static volatile int d_sink;

/* ============================================================
 *  TASK A   priority 15   period 10 ms   ← HIGHEST PRIORITY
 * ============================================================
 *
 * Medical context:
 *   Simulates reading the patient's ECG front-end at 100–500 Hz.
 *   Each sample is passed through a fixed-point IIR (EMA) low-pass filter
 *   to suppress 50/60 Hz mains noise before handing the result to Task B's
 *   arrhythmia detector via the shared variable a_latest_sample.
 *
 * Workload: fixed-point single-pole EMA — Option 2 from the scaffold.
 *   Runtime target: well under 1 ms (aim 10–50 µs).
 *   Measured WCET on Wokwi: ~683–700 µs (see README).
 *
 * Preemption role:
 *   A = preemptor. Its ESP_LOGI tick line appears INSIDE Task D's sort body
 *   in the serial log, proving A interrupted D.
 */
#define A_ITERS 300
static volatile int32_t a_sink;

static void task_a(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(10);

    for (;;) {
        /* Preemption-evidence timestamp: OUTSIDE MEASURE_WCET so the
         * ESP_LOGI call latency does not inflate the WCET measurement. */
        int64_t t = esp_timer_get_time();
        ESP_LOGI(TAG, "task_a tick t=%lld hb=%lu", t, (unsigned long)hb_a);

        MEASURE_WCET(wcet_a_max_us, {
            /*
             * Fixed-point single-pole EMA (IIR low-pass filter).
             * Stands in for "read ADC sample, then smooth it."
             * alpha ≈ 0.1 in Q16.16 fixed-point.
             *
             * Defeats DCE: seeds from a_sink, writes result back to a_sink
             * AND to the shared a_latest_sample for Task B to consume.
             */
            int32_t y = a_sink;
            const int32_t alpha = 6553;   /* ~0.1 in Q16.16 */
            for (int i = 0; i < A_ITERS; i++) {
                int32_t in = (i * 1103515245 + 12345); /* synthetic ECG sample */
                y += (int32_t)(((int64_t)alpha * (in - y)) >> 16);
            }
            a_sink = y;
            a_latest_sample = y;   /* hand off to Task B */
        });

        hb_a++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================
 *  TASK B   priority 10   period 20 ms
 * ============================================================
 *
 * Medical context:
 *   Arrhythmia detector — analyses the ECG sample window produced by Task A.
 *   In a real ICU monitor, QRS detection uses a matched filter: cross-correlate
 *   the ECG sample window against a template waveform and threshold the result.
 *   A positive detection sets the alarm flag for Task C.
 *
 * Workload: single-precision FIR convolution over a circular buffer.
 *   B_SAMP=128 samples, B_TAPS=16 taps → 2048 MACs per period.
 *   Measured WCET on Wokwi: ~4187 µs (see README).
 *
 * Preemption role:
 *   B is preempted BY Task A (higher priority). A's tick line will appear
 *   in the serial log while B is still running.
 */
static void task_b(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(20);

    for (;;) {
        /* Preemption evidence — same pattern as Task A */
        int64_t t = esp_timer_get_time();
        ESP_LOGI(TAG, "task_b tick t=%lld hb=%lu", t, (unsigned long)hb_b);

        MEASURE_WCET(wcet_b_max_us, {
            /*
             * FIR convolution (matched-filter stand-in for QRS detection).
             * Circular buffer indexed with bitmask (B_SAMP must be power of 2).
             * Seeds accumulator from b_sink to prevent DCE.
             */
            float acc = b_sink;
            for (int n = 0; n < B_SAMP; n++) {
                /* Update circular buffer with latest ECG sample (scaled) */
                b_buf[n & (B_SAMP - 1)] += (float)a_latest_sample * 1e-9f;
                for (int k = 0; k < B_TAPS; k++) {
                    acc += b_buf[(n + B_SAMP - k) & (B_SAMP - 1)] * b_coef[k];
                }
            }
            b_sink = acc;

            /* Threshold comparison — stands in for beat-detection decision */
            if (acc > 1e6f || acc < -1e6f) {
                b_alarm_flag = true;
                b_alarm_count++;
            } else {
                b_alarm_flag = false;
            }
        });

        hb_b++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================
 *  TASK C   priority 5   period 50 ms
 * ============================================================
 *
 * Medical context:
 *   Alarm dispatch — prepares and integrity-stamps the alarm/status message
 *   whenever Task B signals an abnormal rhythm. In a real ICU system this
 *   would transmit the packet to the central nursing station over a network.
 *   The CRC-32 stamp ensures the packet was not corrupted in transit.
 *
 * Workload: CRC-32 over a C_LEN-byte telemetry packet.
 *   When b_alarm_flag is set, each byte is XOR'd with the alarm counter LSB
 *   before stamping — simulating "alarm data injected into the frame."
 *   Measured WCET on Wokwi: ~23200 µs (see README).
 *
 * Note: at C_LEN=2048 the WCET (~23 ms) is substantial relative to the
 * 50 ms period. The utilization contribution is 23200/50000 ≈ 0.464.
 * See README schedulability section for full analysis.
 */
static void task_c(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(50);

    for (;;) {
        MEASURE_WCET(wcet_c_max_us, {
            /* Snapshot Task B's alarm outputs before computing */
            bool     alarm     = b_alarm_flag;
            uint32_t alarm_cnt = b_alarm_count;

            uint32_t crc = 0xFFFFFFFFu ^ c_sink;   /* seed from sink — defeats DCE */

            /* CRC-32 (Ethernet/IEEE 802.3 polynomial 0xEDB88320 reflected).
             * When an alarm is active, XOR each packet byte with the alarm
             * counter LSB to inject the alarm state into the frame. */
            for (int n = 0; n < C_LEN; n++) {
                uint8_t byte = c_pkt[n] ^ (alarm ? (uint8_t)(alarm_cnt & 0xFF) : 0u);
                crc ^= byte;
                for (int b = 0; b < 8; b++)
                    crc = (crc >> 1) ^ (0xEDB88320u & (-(int32_t)(crc & 1)));
            }
            c_sink = crc ^ 0xFFFFFFFFu;
        });

        /* Log alarm OUTSIDE MEASURE_WCET so ESP_LOGI doesn't inflate WCET */
        if (b_alarm_flag) {
            ESP_LOGW(TAG, "[ALARM] Arrhythmia event #%lu | CRC=0x%08lX",
                     (unsigned long)b_alarm_count, (unsigned long)c_sink);
        }

        hb_c++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================
 *  TASK D   priority 2   period 100 ms   ← LOWEST PRIORITY
 * ============================================================
 *
 * Medical context:
 *   Audit log / housekeeping — the ICU system maintains a pending-alarm
 *   priority queue. Every 100 ms it re-sorts the queue (worst-case reverse
 *   input) then logs WCET evidence for all four tasks to the serial console.
 *
 * Workload: insertion sort, FORCED worst case (reverse-sorted input every call).
 *   Resetting the array to reverse order before each sort guarantees O(n²)
 *   every invocation — the measured max is the true WCET, not a lucky best case.
 *
 * WATCHDOG FIX (important):
 *   Original D_N=1500 → ~3.7 s WCET on Wokwi. This starved the FreeRTOS
 *   IDLE1 task on Core 1, triggering the task watchdog ("task_wdt: IDLE1 did
 *   not reset the watchdog in time"). Reduced to D_N=200, which gives a WCET
 *   of a few ms — long enough to demonstrate preemption, short enough to keep
 *   the scheduler healthy. The IDLE task must run occasionally to feed the WDT.
 *
 * Preemption role:
 *   D = preemption target. Tasks A, B, and C all interrupt D during its sort.
 *   The wall-clock elapsed time (d_wall_elapsed) exceeds wcet_d_max_us because
 *   it includes time stolen by the higher-priority tasks — that gap IS the
 *   preemption evidence. The hb_a and hb_b delta counters confirm how many
 *   times A and B fired while D was nominally "running."
 */
static void task_d(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(100);

    for (;;) {
        /* Snapshot heartbeats and wall clock BEFORE sort body */
        int64_t  d_wall_start = esp_timer_get_time();
        uint32_t hb_a_before  = hb_a;
        uint32_t hb_b_before  = hb_b;

        ESP_LOGI(TAG, "task_d start t=%lld", d_wall_start);

        MEASURE_WCET(wcet_d_max_us, {
            /*
             * Step 1 — force worst case: reset to reverse-sorted every call.
             * Prevents the compiler from proving the array is constant and
             * also guarantees O(n²) path fires on every invocation.
             */
            for (int i = 0; i < D_N; i++) {
                d_arr[i] = D_N - i + (d_sink & 1);
            }

            /*
             * Step 2 — insertion sort on reverse-sorted input.
             * Every element must shift past all elements to its left → WCET.
             */
            for (int i = 1; i < D_N; i++) {
                int key = d_arr[i];
                int j = i - 1;
                while (j >= 0 && d_arr[j] > key) {
                    d_arr[j + 1] = d_arr[j];
                    j--;
                }
                d_arr[j + 1] = key;
            }
            d_sink = d_arr[D_N / 2];   /* write to volatile sink — defeats DCE */
        });

        /* Wall-clock elapsed includes time stolen by preempting tasks */
        int64_t  d_wall_end     = esp_timer_get_time();
        int64_t  d_wall_elapsed = d_wall_end - d_wall_start;
        uint32_t preempt_a      = hb_a - hb_a_before;
        uint32_t preempt_b      = hb_b - hb_b_before;

        ESP_LOGI(TAG, "task_d done  t=%lld", d_wall_end);

        /* WCET evidence log — paste these lines into the README */
        ESP_LOGI(TAG,
            "WCET(us) A=%llu B=%llu C=%llu D=%llu | "
            "D_wall=%lld D_compute=%llu | "
            "A_preempted_D=%lu B_preempted_D=%lu",
            (unsigned long long)wcet_a_max_us,
            (unsigned long long)wcet_b_max_us,
            (unsigned long long)wcet_c_max_us,
            (unsigned long long)wcet_d_max_us,
            (long long)d_wall_elapsed,
            (unsigned long long)wcet_d_max_us,
            (unsigned long)preempt_a,
            (unsigned long)preempt_b);

        hb_d++;
        vTaskDelayUntil(&last, period);
    }
}

/* ============================================================
 *  WEB MONITOR  (USE_WEBSERVER = 1)
 * ============================================================ */
#if USE_WEBSERVER

static esp_err_t handle_root(httpd_req_t *req)
{
    char buf[2048];
    int n = snprintf(buf, sizeof(buf),
        "<!DOCTYPE html>"
        "<html lang=\"en\"><head>"
        "<meta charset=\"utf-8\"><meta http-equiv=\"refresh\" content=\"1\">"
        "<title>ICU ECG Monitor · 4-task monitor</title>"
        "<style>"
        "  body { font-family: -apple-system, sans-serif; background: #FAFAF5; "
        "         color: #1A1A1A; padding: 1.5rem; }"
        "  h1 { color: #6B4F09; border-bottom: 3px solid #FFC904; "
        "       display: inline-block; padding-bottom: 4px; }"
        "  table { border-collapse: collapse; margin: 1rem 0; }"
        "  th { background: #1A1A1A; color: #FFC904; padding: 8px 14px; "
        "       text-align: left; font-size: 12px; text-transform: uppercase; }"
        "  td { padding: 6px 14px; border-bottom: 1px solid #ddd; }"
        "  td.num { font-variant-numeric: tabular-nums; font-weight: 700; "
        "           color: #6B4F09; }"
        "</style></head>"
        "<body>"
        "<h1>ICU ECG Monitor &mdash; 4-task FreeRTOS</h1>"
        "<table>"
        "<thead><tr><th>Task</th><th>Role</th><th>Period</th>"
        "<th>Priority</th><th>Heartbeats</th><th>WCET (&micro;s)</th></tr></thead>"
        "<tbody>"
        "<tr><td>A &mdash; ECG Sample</td><td>IIR filter</td>"
            "<td>10 ms</td><td>15</td>"
            "<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "<tr><td>B &mdash; Arrhythmia</td><td>FIR convolution</td>"
            "<td>20 ms</td><td>10</td>"
            "<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "<tr><td>C &mdash; Alarm Dispatch</td><td>CRC-32 stamp</td>"
            "<td>50 ms</td><td>5</td>"
            "<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "<tr><td>D &mdash; Audit Log</td><td>Insertion sort (worst-case)</td>"
            "<td>100 ms</td><td>2</td>"
            "<td class=\"num\">%lu</td><td class=\"num\">%llu</td></tr>"
        "</tbody></table>"
        "<p>Arrhythmia events (Task B): %lu</p>"
        "<p>Auto-refresh 1 s &mdash; heartbeats must grow monotonically.</p>"
        "</body></html>",
        (unsigned long)hb_a, (unsigned long long)wcet_a_max_us,
        (unsigned long)hb_b, (unsigned long long)wcet_b_max_us,
        (unsigned long)hb_c, (unsigned long long)wcet_c_max_us,
        (unsigned long)hb_d, (unsigned long long)wcet_d_max_us,
        (unsigned long)b_alarm_count);

    httpd_resp_set_type(req, "text/html");
    httpd_resp_send(req, buf, n);
    return ESP_OK;
}

static httpd_handle_t start_webserver(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.server_port   = 80;
    cfg.core_id       = 0;
    cfg.task_priority = 5;
    cfg.stack_size    = 8192;
    httpd_handle_t s  = NULL;
    if (httpd_start(&s, &cfg) == ESP_OK) {
        httpd_uri_t root = { .uri="/", .method=HTTP_GET,
                             .handler=handle_root, .user_ctx=NULL };
        httpd_register_uri_handler(s, &root);
    }
    return s;
}

static void wifi_event_handler(void *arg, esp_event_base_t base,
                               int32_t id, void *data)
{
    if      (base == WIFI_EVENT && id == WIFI_EVENT_STA_START)        esp_wifi_connect();
    else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) esp_wifi_connect();
    else if (base == IP_EVENT   && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *e = (ip_event_got_ip_t *)data;
        ESP_LOGI(TAG, "IP: " IPSTR, IP2STR(&e->ip_info.ip));
        start_webserver();
    }
}

static void wifi_init_sta(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t init = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init));
    esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,   wifi_event_handler, NULL);
    esp_event_handler_register(IP_EVENT,   IP_EVENT_STA_GOT_IP, wifi_event_handler, NULL);
    wifi_config_t cfg = { .sta = { .ssid = WIFI_SSID, .password = WIFI_PASS,
                                   .threshold.authmode = WIFI_AUTH_OPEN } };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &cfg));
    ESP_ERROR_CHECK(esp_wifi_start());
}

#else  /* USE_WEBSERVER == 0 */

/* ============================================================
 *  TERMINAL MONITOR  (USE_WEBSERVER = 0)
 * ============================================================
 *
 * Pinned to Core 0 (PRO_CPU_NUM) so it stays OFF Core 1 with the real-time
 * workload tasks — same isolation the HTTP server gave you.
 * Prints the monitor table to serial once per second.
 */
static void task_monitor(void *arg)
{
    TickType_t last = xTaskGetTickCount();
    const TickType_t period = pdMS_TO_TICKS(1000);

    for (;;) {
        printf("\n=== ICU ECG Monitor · 4-task monitor ===\n");
        printf("%-26s %-8s %-9s %-12s %-10s\n",
               "Task", "Period", "Priority", "Heartbeats", "WCET(us)");
        printf("%-26s %-8s %-9d %-12lu %-10llu\n",
               "A: ECG Sample (IIR)",    "10 ms",  15, (unsigned long)hb_a, (unsigned long long)wcet_a_max_us);
        printf("%-26s %-8s %-9d %-12lu %-10llu\n",
               "B: Arrhythmia (FIR)",    "20 ms",  10, (unsigned long)hb_b, (unsigned long long)wcet_b_max_us);
        printf("%-26s %-8s %-9d %-12lu %-10llu\n",
               "C: Alarm Dispatch (CRC)","50 ms",   5, (unsigned long)hb_c, (unsigned long long)wcet_c_max_us);
        printf("%-26s %-8s %-9d %-12lu %-10llu\n",
               "D: Audit Log (sort)",    "100 ms",  2, (unsigned long)hb_d, (unsigned long long)wcet_d_max_us);
        printf("Arrhythmia events (B->C): %lu\n", (unsigned long)b_alarm_count);
        printf("(A stalled heartbeat = starved/hung task)\n");

        vTaskDelayUntil(&last, period);
    }
}
#endif /* USE_WEBSERVER */

/* ============================================================
 *  app_main
 * ============================================================ */
void app_main(void)
{
    esp_log_level_set(TAG, ESP_LOG_INFO);
    ESP_LOGI(TAG, "==== App 2 [ICU ECG Monitor] starting — 4-task scheduler demo ====");

    /* Task B: rectangular FIR window + ramp input buffer.
     * Initialized ONCE here — not inside the task — for deterministic WCET. */
    for (int i = 0; i < B_SAMP; i++) b_buf[i]  = (float)(i + 1) * 0.001f;
    for (int i = 0; i < B_TAPS; i++) b_coef[i] = 1.0f / (float)B_TAPS;
    b_sink = 1.0f;   /* non-zero so first acc seed is observable */

    /* Task C: pattern-fill telemetry packet */
    for (int i = 0; i < C_LEN; i++) c_pkt[i] = (uint8_t)(i * 37 + 13);
    c_sink = 0xDEADBEEFu;

    /* Task D: d_arr is reset to reverse order every iteration; just prime sink */
    d_sink = 1;

#if USE_WEBSERVER
    ESP_LOGI(TAG, "Output mode: WEB MONITOR (USE_WEBSERVER=1) — open the printed IP");
    wifi_init_sta();
#else
    ESP_LOGI(TAG, "Output mode: TERMINAL MONITOR (USE_WEBSERVER=0) — no Wi-Fi, serial only");
    /* Monitor on Core 0 — mirrors the HTTP server's Core 1 isolation */
    xTaskCreatePinnedToCore(task_monitor, "task_monitor", 4096, NULL, 1, NULL, PRO_CPU_NUM);
#endif

    /*
     * Create the four real-time tasks, all pinned to Core 1 (APP_CPU_NUM).
     * Priority assignment follows Rate-Monotonic Scheduling (RMS):
     *   shorter period → higher priority.
     *
     *   Task A: period 10 ms  → priority 15  (highest)
     *   Task B: period 20 ms  → priority 10
     *   Task C: period 50 ms  → priority  5
     *   Task D: period 100 ms → priority  2  (lowest)
     */
    xTaskCreatePinnedToCore(task_a, "task_ecg_sample", 4096, NULL, 15, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_b, "task_arrhythmia", 4096, NULL, 10, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_c, "task_alarm",      4096, NULL,  5, NULL, APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_d, "task_audit_log",  4096, NULL,  2, NULL, APP_CPU_NUM);

    ESP_LOGI(TAG, "All tasks created — scheduler running.");
}