# App 2 scaffold — multi-task scheduling
Name: Keva Persaud
Theme: Medical-> ICU Cardidac Monitor 

## What's given
- 4 task skeletons pinned to Core 1, priorities pre-assigned (RMS-style)
- WCET measurement macro: `MEASURE_WCET(max_var, { body })`
- Web monitor with per-task heartbeat counters and live WCET-max display
- Wi-Fi + HTTP server boilerplate (reused from App 1)

## What you implement
1. **Theme rename** — replace `YOURTHEME` everywhere
2. **Four task bodies** — see the comments in each `task_X()` for suggested workloads
3. **WCET measurement** — fill in `task_d` to log all four WCETs to serial periodically
4. **README defense** — see below

## README defense (graded)

Your README must include:

### Task table (mandatory)

| Task | Function | Period (ms) | WCET measured (µs) | WCET + 30% margin (µs) | Deadline | Priority | Core |
|------|----------|------------:|-------------------:|----------------------:|---------:|---------:|-----:|
| A    | …        | 10          | …                  | …                     | 10 ms    | 15       | 1    |
| B    | …        | 20          | …                  | …                     | 20 ms    | 10       | 1    |
| C    | …        | 50          | …                  | …                     | 50 ms    | 5        | 1    |
| D    | …        | 100         | …                  | …                     | 100 ms   | 2        | 1    |

### Schedulability defense

- Total utilization U = ∑ Cᵢ/Tᵢ
- Liu-Layland bound for n=4: U ≤ 4(2^(1/4) − 1) = 0.7568
- If U > Liu-Layland: run response-time analysis on task D (lowest priority)
- Conclusion: feasible / infeasible / borderline. State which.

For n = 4 and the deadline of D=T the bound is 4(2^(1/2)-1) = 0.7568

### Preemption evidence

Add this to one of your task bodies:

```c
int64_t t = esp_timer_get_time();
ESP_LOGI(TAG, "task_a tick t=%lld", t);
```

Repeat in task B. Compare the serial log: when A wakes during a B iteration,
A's log line should appear BEFORE B finishes. That's preemption. Quote two
adjacent log lines that prove it.

### Engineering analysis

1. **Priority defense** — explain each priority. RMS says shortest period &rarr; highest priority. Did you follow it?
2. **3× WCET stress** — if your highest-priority task's WCET tripled, what's the new U? Is the set still feasible?
3. **Preemption proof** — quote the two timestamps showing preemption.

1: 


## Setup in Wokwi
Same shape as App 1. In a fresh Wokwi ESP-IDF project:
1. Replace `diagram.json`, `wokwi.toml`, `sdkconfig.defaults`, and `main/CMakeLists.txt` with this folder's versions.
2. Place this folder's `main.c` at `main/main.c` (delete Wokwi's `main/src/` folder), or leave `main/src/main.c` and edit `main/CMakeLists.txt` to use `SRCS "src/main.c"` + `INCLUDE_DIRS "src"`.
3. Confirm `wokwi.toml`'s `firmware` / `elf` paths reference `app2_tasks_scheduling` &mdash; that must match the `project(...)` name in the top-level `CMakeLists.txt`.
4. Click &#9654; to build.

**Critical for App 2:** the `REQUIRES esp_wifi esp_event esp_http_server esp_netif nvs_flash` line in this folder's `main/CMakeLists.txt` is what links the HTTP/Wi-Fi APIs. If you keep Wokwi's default `main/CMakeLists.txt`, you will get unresolved-symbol errors on `httpd_start`, `esp_wifi_init`, etc. **Use this folder's `main/CMakeLists.txt`.**

### Build locally with ESP-IDF instead

```bash
. $HOME/esp/esp-idf/export.sh
idf.py set-target esp32s3
idf.py build
idf.py -p /dev/ttyUSB0 flash monitor
```

## Viewing the 4-task monitor

After Wi-Fi connects, the serial log prints the IP (`Got IP: 10.13.37.x`). In Wokwi, click the network indicator that appears in the simulator panel once port 80 is up &mdash; the table opens in a new tab and refreshes every second.

What to look for:

- All four heartbeat columns increment monotonically. If one stops growing, that task is starved or hung.
- WCET columns climb during the first few seconds, then stabilize once the worst-case path has been exercised. Use those stable numbers in your README.
- Refresh rate is 1 Hz; if the page itself stalls, your HTTP handler is being preempted &mdash; a teachable moment about Core 0 / Core 1 isolation.

## Honor code

AI is allowed for filling in task bodies. Disclose what you used. Be ready to explain why your WCET measurement is honest (vs. a best-case timing that misses the worst-case path).
